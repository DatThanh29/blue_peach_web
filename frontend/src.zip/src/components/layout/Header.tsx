"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import CartIcon from "@/components/CartIcon";

export default function Header() {
    const [scrolled, setScrolled] = useState(false);
    const tickingRef = useRef(false);

    useEffect(() => {
        const getTop = () => {
            // Ưu tiên scrollY
            const y1 = window.scrollY || 0;
            // Fallback: scrollingElement/html/body
            const se = document.scrollingElement as HTMLElement | null;
            const y2 = se?.scrollTop ?? 0;
            const y3 = document.documentElement?.scrollTop ?? 0;
            const y4 = document.body?.scrollTop ?? 0;
            return Math.max(y1, y2, y3, y4);
        };

        const onScroll = () => {
            const y = getTop();
            setScrolled(y > 80);
        };

        onScroll();

        // window scroll
        window.addEventListener("scroll", onScroll, { passive: true });
        // capture scroll từ các container overflow
        document.addEventListener("scroll", onScroll, { passive: true, capture: true });

        return () => {
            window.removeEventListener("scroll", onScroll);
            document.removeEventListener("scroll", onScroll, true);
        };
    }, []);
    return (
        <header className="w-full">
            {/* 1) Utility Bar (ẩn khi scroll) */}
            <div
                className={[
                    "bg-black text-white overflow-hidden transition-all duration-300",
                    scrolled ? "max-h-0 opacity-0" : "max-h-10 opacity-100",
                ].join(" ")}
            >
                <div className="bp-container flex h-10 items-center justify-between text-[11px] tracking-wide">
                    {/* Left: Location icon + Stores */}
                    <Link
                        href="/stores"
                        aria-label="Stores"
                        className="inline-flex items-center gap-2 opacity-90 hover:opacity-100 transition"
                    >
                        <LocationIcon />
                        <span>Stores</span>
                    </Link>

                    {/* Center: luxury micro text (tuỳ chọn) */}
                    <span className="hidden md:inline opacity-85">
                        Crafted in Silver • Minimal • Timeless
                    </span>

                    {/* Right: account actions */}
                    <div className="flex items-center gap-6">
                        <Link href="/account" className="opacity-90 hover:opacity-100 transition">
                            Login
                        </Link>
                        <Link href="/wishlist" className="opacity-90 hover:opacity-100 transition">
                            Wishlist
                        </Link>
                    </div>
            </div>
        </div>
        <div className="h-px w-full bg-zinc-900" />

            {/* 2) Center Logo Row (giữa Utility và Nav, chỉ hiện khi chưa scroll) */ }
    <div
        className={[
            "transition-all duration-300",
            scrolled ? "max-h-0 opacity-0 overflow-hidden" : "py-6 opacity-100",
        ].join(" ")}
    >
        <div className="bp-container flex justify-center">
            <Link
                href="/"
                className="text-[32px] tracking-[0.45em] font-semibold"
            >
                BLUE PEACH
            </Link>
        </div>
    </div>

    {/* Spacer để không bị nhảy layout khi nav chuyển sang fixed */ }
    { scrolled ? <div className="h-[64px]" /> : null }
    {/* 3) Main Navigation Row (sticky) */ }
    <div
        className={[
            "z-50 bg-white transition-all duration-300",
            scrolled ? "fixed top-0 left-0 right-0 py-3 shadow-[0_2px_10px_rgba(0,0,0,0.06)]" : "relative py-4",
        ].join(" ")}
    >
        <div className="bp-container grid grid-cols-[1fr_auto_1fr] items-center">
            {/* Left: compact wordmark chỉ hiện khi scroll */}
            <div className="justify-self-start">
                <Link
                    href="/"
                    className={[
                        "text-[14px] tracking-[0.32em] font-semibold transition-all duration-200",
                        scrolled ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-1 pointer-events-none",
                    ].join(" ")}
                >
                    BLUE PEACH
                </Link>
            </div>

            {/* Center: Desktop Menu */}
            <nav className="hidden lg:flex justify-self-center items-center flex-nowrap gap-10">
                <div className="relative group inline-flex">
                    <NavItem href="/products" label="Jewelry" />
                    <MegaMenu />
                </div>

                <NavItem href="/collections" label="Collections" />
                <NavItem href="/products?sort=new" label="New In" />
                <NavItem href="/products?category=gifts" label="Gifts" />
            </nav>

            {/* Right: Icons */}
            <div className="justify-self-end flex items-center gap-2">
                <button
                    aria-label="Search"
                    className="h-10 w-10 inline-flex items-center justify-center rounded-md hover:bg-zinc-100 transition"
                >
                    <SearchIcon />
                </button>

                <CartIcon />

                <button
                    aria-label="Open menu"
                    className="lg:hidden h-10 w-10 inline-flex items-center justify-center rounded-md hover:bg-zinc-100 transition"
                >
                    <MenuIcon />
                </button>
            </div>
        </div>

        {/* divider line mảnh kiểu Swarovski */}
        <div className="h-px w-full bg-zinc-100" />
    </div>
        </header >
    );
}

function NavItem({ href, label }: { href: string; label: string }) {
    return (
        <Link href={href} className="relative group py-2">
            <span className="text-[13px] tracking-wide">{label}</span>
            <span className="absolute left-0 -bottom-[2px] h-[1px] w-0 bg-black transition-all duration-300 group-hover:w-full" />
        </Link>
    );
}

/**
 * Mega menu full-width (theo container) + hover bridge để không tụt hover.
 * Dropdown này dựa vào group-hover của wrapper ở trên (div.relative.group).
 */
function MegaMenu() {
    return (
        // Hover Bridge: pt-4 là vùng đệm để chuột đi xuống không bị mất hover
        <div className="absolute left-1/2 top-full hidden -translate-x-1/2 pt-4 group-hover:block">
            <div className="w-[980px] rounded-2xl bg-white shadow-[0_20px_60px_rgba(0,0,0,0.12)] p-10">
                <div className="grid grid-cols-4 gap-10">

                    <MenuCol
                        title="Necklaces"
                        items={[
                            { t: "Pendants", href: "/products?category=necklaces&type=pendants" },
                            { t: "Chokers", href: "/products?category=necklaces&type=chokers" },
                            { t: "Layered", href: "/products?category=necklaces&type=layered" },
                        ]}
                    />

                    <MenuCol
                        title="Earrings"
                        items={[
                            { t: "Stud", href: "/products?category=earrings&type=stud" },
                            { t: "Hoop", href: "/products?category=earrings&type=hoop" },
                            { t: "Drop", href: "/products?category=earrings&type=drop" },
                        ]}
                    />

                    <MenuCol
                        title="Rings"
                        items={[
                            { t: "Silver", href: "/products?category=rings&type=silver" },
                            { t: "Minimal", href: "/products?category=rings&type=minimal" },
                            { t: "Statement", href: "/products?category=rings&type=statement" },
                        ]}
                    />

                    {/* Preview image */}
                    <div className="rounded-xl overflow-hidden bg-zinc-100">
                        <img
                            src="/menu-preview.jpg"
                            alt="Preview"
                            className="h-full w-full object-cover"
                        />
                    </div>

                </div>
            </div>
        </div>
    );
}

function MenuCol({
    title,
    items,
}: {
    title: string;
    items: { t: string; href: string }[];
}) {
    return (
        <div>
            <h4 className="text-sm font-semibold mb-4">{title}</h4>
            <ul className="space-y-2 text-[13px] text-zinc-600">
                {items.map((it) => (
                    <li key={it.t}>
                        <Link href={it.href} className="hover:text-black transition">
                            {it.t}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}

function SearchIcon() {
    return (
        <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="opacity-95"
        >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
        </svg>
    );
}

function MenuIcon() {
    return (
        <svg
            width="22"
            height="22"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="opacity-95"
        >
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
    );
}
function LocationIcon() {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="opacity-95"
    >
      <path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
