"use client";

import { CartProvider } from "@/contexts/CartContext";
import Header from "@/components/layout/Header";
import { ReactNode } from "react";

export default function RootLayoutClient({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <CartProvider>
      <Header />
      {children}
    </CartProvider>
  );
}