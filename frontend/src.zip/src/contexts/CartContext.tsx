"use client";

import React, { createContext, useCallback, useEffect, useState } from "react";

export type CartItem = {
  ma_san_pham: string;
  ten_san_pham: string;
  gia_ban: number;
  primary_image?: string | null;
  qty: number;
};

type CartContextType = {
  items: CartItem[];
  addItem: (item: Omit<CartItem, "qty">, qty?: number) => void;
  updateQty: (ma_san_pham: string, qty: number) => void;
  removeItem: (ma_san_pham: string) => void;
  clearCart: () => void;
  total: number;
  isLoading: boolean;
};

export const CartContext = createContext<CartContextType | undefined>(undefined);

const STORAGE_KEY = "bluepeach_cart_v1";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load từ localStorage khi mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setItems(JSON.parse(stored) as CartItem[]);
      }
    } catch (error) {
      console.error("Failed to load cart from localStorage:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Save vào localStorage khi items thay đổi
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    }
  }, [items, isLoading]);

  // Thêm sản phẩm vào giỏ
  const addItem = useCallback((item: Omit<CartItem, "qty">, qty = 1) => {
    setItems((prev) => {
      const idx = prev.findIndex((x) => x.ma_san_pham === item.ma_san_pham);
      if (idx >= 0) {
        // Sản phẩm đã tồn tại, tăng số lượng
        const newItems = [...prev];
        newItems[idx] = { ...newItems[idx], qty: newItems[idx].qty + qty };
        return newItems;
      } else {
        // Sản phẩm mới
        return [...prev, { ...item, qty }];
      }
    });
  }, []);

  // Cập nhật số lượng sản phẩm
  const updateQty = useCallback((ma_san_pham: string, qty: number) => {
    setItems((prev) =>
      prev
        .map((x) => (x.ma_san_pham === ma_san_pham ? { ...x, qty } : x))
        .filter((x) => x.qty > 0)
    );
  }, []);

  // Xóa sản phẩm khỏi giỏ
  const removeItem = useCallback((ma_san_pham: string) => {
    setItems((prev) => prev.filter((x) => x.ma_san_pham !== ma_san_pham));
  }, []);

  // Xóa tất cả sản phẩm
  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  // Tính tổng tiền
  const total = items.reduce(
    (sum, item) => sum + Number(item.gia_ban) * item.qty,
    0
  );

  const value: CartContextType = {
    items,
    addItem,
    updateQty,
    removeItem,
    clearCart,
    total,
    isLoading,
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}
