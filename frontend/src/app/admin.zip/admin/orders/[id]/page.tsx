"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { API_BASE_URL } from "@/lib/api";

const STATUS = ["pending", "processing", "shipped", "completed", "cancelled"] as const;

export default function AdminOrderDetailPage() {
  const params = useParams<{ id: string }>();
  const orderId = params?.id;

  const [order, setOrder] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [status, setStatus] = useState<string>("pending");
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    if (!orderId) return;

    setMsg(null);
    const res = await fetch(`${API_BASE_URL}/api/orders/${orderId}`, { cache: "no-store" });
    const json = await res.json();
    setOrder(json);
    setItems(json.items ?? []);
    setStatus(json.trang_thai_don ?? "pending");
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  async function saveStatus() {
    if (!orderId) {
      setMsg("❌ Missing order id");
      return;
    }

    setLoading(true);
    setMsg(null);

    try {
      const res = await fetch(`${API_BASE_URL}/api/admin/orders/${orderId}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_ADMIN_TOKEN ?? ""}`,
        },
        body: JSON.stringify({ trang_thai_don: status }),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json?.error ?? `HTTP ${res.status}`);

      setMsg("✅ Cập nhật trạng thái thành công");
      await load();
    } catch (e: any) {
      setMsg(`❌ ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  if (!orderId) {
    return <main style={{ padding: 24 }}>Loading params...</main>;
  }

  if (!order) {
    return <main style={{ padding: 24 }}>Loading order...</main>;
  }

  const snap = order.dia_chi_giao_hang_snapshot || {};

  return (
    <main style={{ padding: 24, maxWidth: 1000, margin: "0 auto" }}>
      <a href="/admin/orders">← Back to orders</a>
      <h1>Order #{order.ma_don_hang}</h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
          <h3>Thông tin khách</h3>
          <div><b>Họ tên:</b> {snap.customer_name ?? "—"}</div>
          <div><b>SĐT:</b> {snap.phone ?? "—"}</div>
          <div><b>Địa chỉ:</b> {snap.address ?? "—"}</div>
        </div>

        <div style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
          <h3>Trạng thái</h3>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <select value={status} onChange={(e) => setStatus(e.target.value)} style={{ padding: 10 }}>
              {STATUS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>

            <button onClick={saveStatus} disabled={loading} style={{ padding: "10px 14px" }}>
              {loading ? "Đang lưu..." : "Lưu"}
            </button>
          </div>

          {msg ? <p style={{ marginTop: 10 }}>{msg}</p> : null}
        </div>
      </div>

      <div style={{ marginTop: 16, border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
        <h3>Items</h3>
        {items.map((it, idx) => (
          <div
            key={idx}
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 120px 160px",
              gap: 12,
              padding: "8px 0",
              borderTop: idx ? "1px solid #f2f2f2" : "none",
            }}
          >
            <div>{it.ma_san_pham}</div>
            <div>x{it.so_luong_mua}</div>
            <div style={{ textAlign: "right" }}>
              {Number(it.thanh_tien).toLocaleString("vi-VN")}đ
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
