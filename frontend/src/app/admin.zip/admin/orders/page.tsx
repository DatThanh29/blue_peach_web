"use client";

import { useEffect, useState } from "react";
import { API_BASE_URL } from "@/lib/api";

type Order = {
  ma_don_hang: string;
  ngay_dat_hang: string;
  tong_thanh_toan: number;
  trang_thai_don: string;
  trang_thai_thanh_toan: string;
  hinh_thuc_thanh_toan: string;
  dia_chi_giao_hang_snapshot: any;
};

export default function AdminOrdersPage() {
  const [items, setItems] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setErr(null);

    try {
      const res = await fetch(`${API_BASE_URL}/api/admin/orders?limit=50&offset=0`, {
        headers: {
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_ADMIN_TOKEN ?? ""}`,
        },
        cache: "no-store",
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json?.error ?? `HTTP ${res.status}`);

      setItems(json.items ?? []);
    } catch (e: any) {
      setErr(e.message ?? "Load failed");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
      <h1>Admin • Orders</h1>

      <div style={{ margin: "10px 0 16px", display: "flex", gap: 10 }}>
        <a href="/" style={{ textDecoration: "none" }}>← Home</a>
        <button onClick={load} disabled={loading} style={{ padding: "8px 12px" }}>
          {loading ? "Loading..." : "Reload"}
        </button>
      </div>

      {err ? <p style={{ color: "crimson" }}>❌ {err}</p> : null}

      <div style={{ display: "grid", gap: 10 }}>
        {items.map((o) => {
          const snap = o.dia_chi_giao_hang_snapshot || {};
          return (
            <a
              key={o.ma_don_hang}
              href={`/admin/orders/${o.ma_don_hang}`}
              style={{
                textDecoration: "none",
                color: "inherit",
                border: "1px solid #eee",
                borderRadius: 12,
                padding: 12,
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                <div>
                  <div style={{ fontWeight: 700 }}>#{o.ma_don_hang}</div>
                  <div style={{ opacity: 0.75 }}>
                    {snap.customer_name ?? "—"} • {snap.phone ?? "—"} • {snap.address ?? "—"}
                  </div>
                  <div style={{ opacity: 0.7, fontSize: 12 }}>
                    {o.ngay_dat_hang ? new Date(o.ngay_dat_hang).toLocaleString("vi-VN") : ""}
                  </div>
                </div>

                <div style={{ textAlign: "right" }}>
                  <div style={{ fontWeight: 700 }}>
                    {Number(o.tong_thanh_toan).toLocaleString("vi-VN")}đ
                  </div>
                  <div style={{ opacity: 0.75 }}>Trạng thái: {o.trang_thai_don}</div>
                  <div style={{ opacity: 0.75 }}>
                    TT: {o.trang_thai_thanh_toan} • {o.hinh_thuc_thanh_toan}
                  </div>
                </div>
              </div>
            </a>
          );
        })}

        {!loading && items.length === 0 ? <p>Chưa có đơn hàng.</p> : null}
      </div>
    </main>
  );
}
